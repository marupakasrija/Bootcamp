# srija-hello

A small Python package to greet the world or a given name.


srija-hello           # prints "Hello, world!"
srija-hello Alice     # prints "Hello, Alice!"
