def say_hello(name="world"):
    return f"Hello, {name}!"
