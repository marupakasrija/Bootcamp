# srija-hello

A small Python package to greet the world or a given name.

## 📦 Installation

To install the package from TestPyPI, use:

```bash
pip install -i https://test.pypi.org/simple/ srija-hello
🚀 Usage
After installing, run from the command line:

bash
Copy
Edit
srija-hello           # prints "Hello, world!"
srija-hello Alice     # prints "Hello, Alice!"
🔗 Package Page
View on TestPyPI

🛠️ License
MIT License